title: Ubuntu安装配置Nginx和PHP环境
date: '2019-08-23 17:12:28'
updated: '2019-08-26 18:14:19'
tags: [Linux, PHP, Nginx]
permalink: /articles/2019/08/23/1566551548746.html
---
![](https://img.hacpai.com/bing/20190328.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## 前言
作为一个Javaer,不巧的是需要部署一套php程序,遂尝试配置PHP环境.

服务器之前已经安装Jdk1.8,安装Nginx,docker等程序,放置了多个应用,通过Nginx代理访问

如果是纯粹需要PHP环境推荐使用一键安装LNMP(Linx+Nginx+Mysql+PHP)或者LAMP(A=Apache)

详情参考:[**LNMP一键安装**](https://https://lnmp.org/)

或者使用docker,选择一个PHP镜像,可以大大减少折腾,本文着重在于手动安装Nginx,PHP已经配置相关环境

## 安装Nginx

 之前服务器已经安装过了Nginx,这里简单说一下.对了,我的服务器是Ubuntu16.04

### 更新源

```
apt update
```
### 通过源安装Nginx
```
apt install nginx
```
## 安装PHP及相关模块
```
apt install php php-fpm php-mysql
```
### 查看PHP环境
```
php -v
```
![image.png](https://img.hacpai.com/file/2019/08/image-4965d09d.png)
可以看到源里面的PHP版本还是比较新,是PHP7.2
## 配置
### 修改PHP配置文件
```
vim /etc/php/7.2/fpm/pool.d/www.conf
```
我这里是php7.2版本,所以路径是7.2,找对自己对应的版本修改

修改里面配置,大概在36行,修改为127.0.0.1 最终如下
![image.png](https://img.hacpai.com/file/2019/08/image-a57d8ef5.png)
### 修改Nginx配置文件

```
vim /etc/nginx/sites-enabled/default
```
加入如下内容
```
location ~ \.php$ {
                fastcgi_pass 127.0.0.1:9000;
                fastcgi_index index.php;
                fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
                include fastcgi_params;
}
```
如图
![image.png](https://img.hacpai.com/file/2019/08/image-81a9a783.png)

## 重启
### 重启Nginx
```
service nginx restart
```
### 重启php-fpm
```
service php7.2-fpm restart
```
restart重启,start启动,stop停止

有些服务器需要执行
```
service php-fpm restart
```
看情况操作

## 结束
如果不出意外,现在支持PHP程序了.如果出现问题,Google一下都能解决,我在配置的时候就遇到一起奇葩问题,按道理都是对的,可就是访问不到PHP程序,最终万能重启法解决

顺便说一下
* Nginx默认地址是/var/www/html需要把程序放到这里,当然这个地址也是可以修改的
* Nginx日志文件在/var/log下,遇到问题可查看日志排查
