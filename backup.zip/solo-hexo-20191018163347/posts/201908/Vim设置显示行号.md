title: Vim设置显示行号
date: '2019-08-23 17:46:41'
updated: '2019-08-23 17:47:42'
tags: [Linux, Vim]
permalink: /articles/2019/08/23/1566553601605.html
---
![](https://img.hacpai.com/bing/20190328.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

# 前言
vim是一款强大的编辑器
# 设置显示
## 编辑任意文件

![image.png](https://img.hacpai.com/file/2019/08/image-76c12f75.png)

默认是这样的,没有显示行号
## 按一下Esc键，并输入:（冒号）
![image.png](https://img.hacpai.com/file/2019/08/image-7395ec6f.png)

最下面会变成这样样子

## 输入set number并回车

![image.png](https://img.hacpai.com/file/2019/08/image-d3fa03b3.png)

行号就显示出来了

## set nonumber 取消行号显示



