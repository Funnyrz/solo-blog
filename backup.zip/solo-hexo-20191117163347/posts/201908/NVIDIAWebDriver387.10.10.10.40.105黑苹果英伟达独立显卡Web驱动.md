title: NVIDIA Web Driver 387.10.10.10.40.105黑苹果英伟达独立显卡Web驱动
date: '2019-08-02 14:51:07'
updated: '2019-08-02 14:51:07'
tags: [黑苹果, 驱动]
permalink: /articles/2019/08/02/1564728666939.html
---
WebDriver黑苹果显卡[驱动](http://www.pc6.com/mach/qdrj/)Mac版是Mac平台上的一款显卡驱动工具，WebDriver黑苹果显卡驱动Mac版是一款黑苹果英伟达显卡驱动，这次更新英伟达加入了10xx系列的支持，包括1050、1060、1070和1080等。

之前在网上找到一个驱动,但是版本不匹配,一直装不上,这个是在英伟达官网下载,亲测可用

!![d87559e741004512963859d234eda23f.png](https://img.hacpai.com/file/2019/08/d87559e741004512963859d234eda23f-051e2ed7.png)




![50c5863ebeaa4502a2037a1913ed5f5b.png](https://img.hacpai.com/file/2019/08/50c5863ebeaa4502a2037a1913ed5f5b-518a7457.png)




下载地址:[<span style="color:#e74c3c">点击下载</span>](http://pan.bxmac.com/?/WebDriver-387.10.10.10.40.105.pkg)