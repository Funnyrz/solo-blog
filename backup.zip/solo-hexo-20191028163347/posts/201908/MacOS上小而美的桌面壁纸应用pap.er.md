title: MacOS上小而美的桌面壁纸应用pap.er
date: '2019-08-02 14:53:53'
updated: '2019-08-02 14:53:53'
tags: [推荐软件]
permalink: /articles/2019/08/02/1564728832918.html
---
无论多么优秀,多么漂亮的壁纸,也抵不过时间,抵不过岁月的审美,时间久了,都会厌倦.

今天推荐一款小而美的壁纸软件,仅适用于MacOS,量身打造

### 附上官网链接:[<span style="color:#e74c3c">Pap.er - 专为 Mac 设计的壁纸应用</span>](http://paper.meiyuan.in/)

&nbsp;

![dbc63e85fac14781a44adf020d4bf461.png](https://img.hacpai.com/file/2019/08/dbc63e85fac14781a44adf020d4bf461-57a79267.png)


![8d66255b7bc9474a9f6574286288d670.png](https://img.hacpai.com/file/2019/08/8d66255b7bc9474a9f6574286288d670-3306f1f3.png)


![b027923e79d141c29c2422505dc59dcd.png](https://img.hacpai.com/file/2019/08/b027923e79d141c29c2422505dc59dcd-ddb2229e.png)

![a42ab0ce9f5940708459bfdb8a4c04aa.png](https://img.hacpai.com/file/2019/08/a42ab0ce9f5940708459bfdb8a4c04aa-98234327.png)



### 下载地址:&nbsp;&nbsp;[<span style="color:#e74c3c">pap.er_v3.3.dmg</span>](http://pan.bxmac.com/?/pap.er_v3.3.dmg)