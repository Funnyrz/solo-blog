title: 站点Nginx配置HTTPS以及HTTPS下访问静态资源
date: '2019-10-31 17:24:48'
updated: '2019-10-31 17:24:48'
tags: [Linux, Nginx]
permalink: /articles/2019/10/31/1572513888548.html
---
![](https://img.hacpai.com/bing/20171113.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# 前言

刚刚开始站点已经支持了HTTPS协议访问,所以出现了短暂无法访问的情况.同时也暂时保留了HTTP协议访问,需要观察HTTPS下时候出现不兼容的情况.本篇是记录Nginx反向代理下HTTPS访问静态资源无法加载的问题.



# 启用HTTPS

站点支持HTTPS是需要证书的,我是在阿里云申请的免费证书,详情请移步阿里云,证书申请后需要阿里云审核,这个时间还是比较长(至少几个小时起步)
审核通过后会看到这样的界面
![image.png](https://img.hacpai.com/file/2019/10/image-d74d5ca1.png)

然后我们点击下载证书,会有好几个选择,因为我是Nginx配置,所以我选择Nginx下载
![image.png](https://img.hacpai.com/file/2019/10/image-03ff85d0.png)

下载后是一个压缩包,里面包含2个文件,一个是key后缀,一个是pem后缀

![image.png](https://img.hacpai.com/file/2019/10/image-d8ecf48f.png)

把文件上传到服务器地址是**/etc/nginx/cert/**
如果没有这个目录自己新建一下

然后查看帮助,按阿里云的教程来操作
![image.png](https://img.hacpai.com/file/2019/10/image-e02717bf.png)

看教程需要在Nginx里面配置一段代码,那么复制过去
```
server {
 listen 443;
 server_name localhost;
 ssl on;
 root html;
 index index.html index.htm;
 ssl_certificate   cert/a.pem;
 ssl_certificate_key  cert/a.key;
 ssl_session_timeout 5m;
 ssl_ciphers ECDHE-RSA-AES128-GCM-SHA256:ECDHE:ECDH:AES:HIGH:!NULL:!aNULL:!MD5:!ADH:!RC4;
 ssl_protocols TLSv1 TLSv1.1 TLSv1.2;
 ssl_prefer_server_ciphers on;
 location / {
     root html;
     index index.html index.htm;
 }
}
```
然后把cert/a.pem;和cert/a.key;修改成上传到服务这个2个文件的路径,重启Nginx,不出意外的话就可以了

如果出了意外去网上检索相关错误信息吧!

# 配置访问静态资源文件

这个加一句就可以
**add_header Content-Security-Policy upgrade-insecure-requests;**

# 我的配置


```
server {
	listen 443;
	server_name localhost;
	ssl on;
	root html;
	index index.html index.htm;
	ssl_certificate   /etc/ssl/certs/2906065_zxacn.com.pem;
	ssl_certificate_key  /etc/ssl/certs/2906065_zxacn.com.key;
	ssl_session_timeout 5m;
	ssl_ciphers ECDHE-RSA-AES128-GCM-SHA256:ECDHE:ECDH:AES:HIGH:!NULL:!aNULL:!MD5:!ADH:!RC4;
	ssl_protocols TLSv1 TLSv1.1 TLSv1.2;
	ssl_prefer_server_ciphers on;

	location / {
			add_header Content-Security-Policy upgrade-insecure-requests;
			proxy_set_header Host $host;
			proxy_set_header X-Real-Ip $remote_addr;
			proxy_set_header X-Forwarded-For $remote_addr;
			proxy_pass http://localhost:8090;
	}
}

```

