title: Web H5 Vue项目打包为安卓 iOS或桌面Windows应用
date: '2019-09-18 11:57:19'
updated: '2019-09-18 11:57:19'
tags: [待分类]
permalink: /articles/2019/09/18/1568779039385.html
---
![](https://img.hacpai.com/bing/20180807.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## 前言
因为谷歌V8引擎,JavaScript性能得到很大的加强.相比于原生App,开发Web应用要便捷不少,如果能让开发的web app能打包到其他平台那就太完美不过了

有需求就有市场,那就有人做,所以今天介绍一下如何把web应用,用H5开发或者Vue等前端技术开发的应用打包到不同平台,实现一套代码适用于所有平台

## uni-app
**首先是一个最新发现的一个强大的神器uni-app,一下是官网介绍**

**[这里是官网](https://uniapp.dcloud.io/)**

`uni-app` 是一个使用 [Vue.js](https://vuejs.org/) 开发所有前端应用的框架，开发者编写一套代码，可发布到iOS、Android、H5、以及各种小程序（微信/支付宝/百度/头条/QQ/钉钉）等多个平台。

即使不跨端，`uni-app`同时也是更好的小程序开发框架。详见[评测](https://ask.dcloud.net.cn/article/35947)

`DCloud`公司拥有350万开发者用户，旗下`uni-app`有5万+案例、600+插件、50+微信/qq群、更高的百度指数，可以放心选择。

![image.png](https://img.hacpai.com/file/2019/09/image-7edda87e.png)

看介绍是不是很牛X,我用里面的模板打包了一个电商项目演示

[SMG965020190918112128.mp4](https://img.hacpai.com/file/2019/09/SMG965020190918112128-9b91c201.mp4)


更多的这里就不作做介绍了,去官网好好了解吧


## Electron

上面介绍的uni-app确实强大,但似乎不支持桌面应用程序,接下来介绍的这个项目就是为桌面跨平台的解决方案

**Electron--使用 JavaScript, HTML 和 CSS 构建跨平台的桌面应用**

[Electron](https://electronjs.org/)是由Github开发，用HTML，CSS和JavaScript来构建跨平台桌面应用程序的一个开源库。 Electron通过将[Chromium](https://www.chromium.org/Home)和[Node.js](https://nodejs.org/)合并到同一个运行时环境中，并将其打包为Mac，Windows和Linux系统下的应用来实现这一目的。

Electron于2013年作为构建Github上可编程的文本编辑器[Atom](https://atom.io/)的框架而被开发出来。这两个项目在2014春季开源。

目前它已成为开源开发者、初创企业和老牌公司常用的开发工具

以下来自官网的截图
![fehelperelectronjsorg1568778748621.png](https://img.hacpai.com/file/2019/09/fehelperelectronjsorg1568778748621-11931d8f.png)

超级牛X的VsCode就是使用Electron开发的,能得到微软的认可应该不会差
