title: I5 7400（集显HD630）完美EFI(colver)分享
date: '2019-08-02 14:57:07'
updated: '2019-08-28 17:26:37'
tags: [黑苹果, Hacktoish]
permalink: /articles/2019/08/02/1564729027155.html
---
![](https://img.hacpai.com/bing/20181229.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

**i5 7400（集显HD630）完美EFI(colver)分享**
## 前言
之前在参考网上黑苹果教程写了一篇博文,地址:[黑苹果10.13.6双硬盘双系统安装教程2019 ](/articles/2019/08/02/1564717450462.html),如果已经700多的阅读量,中间还被我误删库,丢了很多数据,心累啊,后面差不多都恢复了,阅读量也重新计算了,这样应该有上千的阅读量,但是很奇怪,至今没有一条评论,没人说要分享EFI文件,是看文章朋友都和我的电脑配置不一样吗? 

我这里还是把我的配置分享出来吧!
## 下载地址
> 下载地址:[点击下载](http://pan.bxmac.com/?/EFI%28i5-7400%29.zip)
## 特别说明
PS:**因为我上传的是已经配置过的EFI,我屏蔽过启动项,
第一次安装的同学请把红色内容删除,否则安装的时候没有install的选项,懒得修改重新上传了**

**文件名:config.plist**

![image.png](https://img.hacpai.com/file/2019/08/image-2560f065.png)
## Github项目
抽空把代码放到了github上托管已经删掉了屏蔽启动项,下载即用

**项目地址:[https://github.com/Funnyrz/Hacktoish-EFI-I5-HD630](https://github.com/Funnyrz/Hacktoish-EFI-I5-HD630)**

## 联系方式
如有问题可以添加我QQ
**QQ:746108479**

