title: 同步github上源码失败时自动重试脚本
date: '2019-08-02 15:14:11'
updated: '2019-08-02 15:14:11'
tags: [Linux]
permalink: /articles/2019/08/02/1564730051837.html
---
在同步一下较大,几十G源码时,经常会因为网络原因导致失败,需要人为手动重试
所以写了这个自动重试脚本

使用下面的脚本就可以在出错时自动重试了

新建一个.sh脚本,把下面的代码复制到脚本里面然后执行脚本,注意脚本放到源码的目录

```
repo sync

while [ $? = 1 ]; do

echo "sync failed, try 3 seconds later..."

sleep 3

repo sync

done
```