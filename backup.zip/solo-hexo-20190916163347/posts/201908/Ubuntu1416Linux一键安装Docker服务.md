title: Ubuntu14,16,Linux一键安装Docker服务
date: '2019-08-27 12:35:05'
updated: '2019-08-27 12:35:05'
tags: [Linux, Ubuntu, Docker]
permalink: /articles/2019/08/27/1566880504868.html
---
![](https://img.hacpai.com/bing/20180710.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## 前言
本片介绍如何在Linux发行版Ubuntu下通过源安装docker服务,理论上16,14甚至更高或更低都一样

### 1.更新源
```
apt-get update
```
Ubuntu高版本支持apt-get简写apt,低版本仍需要apt-get

### 2.安装docker服务

在命令行直接输入docker会出现如下提示

```
docker
```
![image.png](https://img.hacpai.com/file/2019/08/image-048bb850.png)

Ubuntu已经给了通过源安装的命令,直接复制执行

```
apt install docker.io
```
中途需要输入Y并回车,当然也可以在执行命令是跟一个-y的参数就不会出现了

执行完成后,docker服务就安装好了,查看下版本
### 3.查看docker版本


```
docker -v
```
![image.png](https://img.hacpai.com/file/2019/08/image-7e18de78.png)

没问题,至此docker服务就安装完成了
