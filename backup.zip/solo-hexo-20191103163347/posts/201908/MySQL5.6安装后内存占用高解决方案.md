title: MySQL5.6安装后内存占用高解决方案
date: '2019-08-02 15:13:19'
updated: '2019-08-02 15:13:19'
tags: [Linux, MySql]
permalink: /articles/2019/08/02/1564729999649.html
---
距离MySQL 5.6正式发布已经有比较长的时间了，目前Oracle官网上的最新GA版本MySQL server也为5.6。但reizhi在安装配置后却发现其内存占用居高不下，无论如何调整cache甚至禁用InnoDB都不能解决。由于VPS仅有1GB内存，在开启常用的Web服务之后，无力再为MySQL提供400MB以上的物理内存。

通过网络爬文，MySQL 5.6相比于前代GA版本性能提升显著，但默认缓存设置对于小型站点并不合理。通过修改my.ini文件中的performance_schema_max_table_instances参数，能够有效降低内存占用。

默认my.ini文件位置：C:\Documents and Settings\All Users\Application Data\MySQL\MySQL Server 5.6

修改参数：
```
performance_schema_max_table_instances=400
table_definition_cache=400
table_open_cache=256
```
保存之后重新启动MySQL服务，其内存占用即可从400MB以上降低至40MB左右。

 

贴出另一篇解决方案

 

Performance Schema
这是在 5.6 版本中开始默认开启的一项功能，它会在 MySQL 启动之后悄悄占用 400M 左右的内存来加速 MySQL 的运行——对于动辄近百的企业级服务器来说，可能不值一提，但是对于咱们这种屌丝小 vps （我这个 1GB 独立内存算是不错的了）来说，可就要顶了天了！

所以，这大概就是为什么我的服务器最近连续死机两次了。

要关闭 Performance Schema ，在你的 MySQL 配置文件的  [mysqld] 字段添加一句 performance_schema = off

这样，我的数据库就稳定在 300M 内存左右了。