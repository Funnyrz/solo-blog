title: Flutter在构建时卡住不动的解决方案
date: '2019-08-02 15:10:18'
updated: '2019-08-02 15:10:18'
tags: [Linux, 随笔]
permalink: /articles/2019/08/02/1564729818249.html
---
Flutter构建时卡经常卡住,原因应该是墙的问题

只要把默认的 package 获取地址改为访问没有问题的镜像站就可以了

Resolving dependencies卡住
package get卡住

 

解决方案1:

通过全部代理可以解决

解决方案2:

修改访问镜像地址

 

Linux 或 Mac
```
export PUB_HOSTED_URL=https://pub.flutter-io.cn
export FLUTTER_STORAGE_BASE_URL=https://storage.flutter-io.cn
```
Windows
新增两个环境变量即可
```
PUB_HOSTED_URL ===== https://pub.flutter-io.cn
FLUTTER_STORAGE_BASE_URL ===== https://storage.flutter-io.cn
```
执行一下 flutter doctor命令