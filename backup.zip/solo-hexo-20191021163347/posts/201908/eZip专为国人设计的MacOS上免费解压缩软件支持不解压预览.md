title: eZip专为国人设计的MacOS上免费解压缩软件支持不解压预览
date: '2019-08-02 14:55:32'
updated: '2019-08-02 14:55:32'
tags: [推荐软件]
permalink: /articles/2019/08/02/1564728932551.html
---
![d209270d651a4d539124cf5774108211.jpg](https://img.hacpai.com/file/2019/08/d209270d651a4d539124cf5774108211-4e6c5fe6.jpg)


**完美兼容 Mojave**

支持 Mojave, High Sierra, Sierra, EI Caption, Yosemite 苹果操作系统。

**支持超过 20 种压缩格式**

Supports more than 20 popular archive formats such as rar, zip, 7z, tar, gz, bz2, iso, xz, lzma, apk, lz4. Perfect handling of encryption and decryption!

![52e2ccebc07e4ee393c6624d03c718c9.png](https://img.hacpai.com/file/2019/08/52e2ccebc07e4ee393c6624d03c718c9-9f446dab.png)

&nbsp;

**批量文件加密**

轻松保护私密文件，加密后安全更省心。可随意丢到第三方云盘，再也不怕隐私泄露！只要不知道你的密码，谁也别想打开&ldquo;你的&rdquo;文件！

&nbsp;

![effbe97fe301414686bb2e5d9f441225.png](https://img.hacpai.com/file/2019/08/effbe97fe301414686bb2e5d9f441225-2e5764cb.png)

&nbsp;

![d7b1592eee0c4e4ea2fb7631f6306f19.png](https://img.hacpai.com/file/2019/08/d7b1592eee0c4e4ea2fb7631f6306f19-a8d854f6.png)


&nbsp;

*   支持不解压进行预览
*   支持 QuickLook
*   支持部分文件提取（ 10.12 及以上系统支持&ldquo;拖拽&rdquo;解压）
*   支持的解压格式，zip/7z/rar 等超过 20 种
*   支持压缩格式：zip 和 7z
*   支持密码
*   支持分卷功能
*   支持压缩包内文件查找和过滤
*   支持批量文件加密解密功能

另外，考虑到用户的使用体验，还做到了：

*   安全（基于 Sandbox ）
*   永久免费
*   平滑升级

### 下载地址：&nbsp;[<span style="color:#e74c3c">点击下载</span>](http://pan.bxmac.com/?/eZip_V1.6.dmg)