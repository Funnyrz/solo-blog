title: (PC全平台)Http下载工具，支持多连接分块下载(满速下载百度云)
date: '2019-08-02 15:09:01'
updated: '2019-08-23 18:00:01'
tags: [破解, 百度云, 推荐软件]
permalink: /articles/2019/08/02/1564729741128.html
---
![2f767541541d49b6a4bdee3155a66eb6.jpg](https://img.hacpai.com/file/2019/08/2f767541541d49b6a4bdee3155a66eb6-58c881c4.jpg)

## 满速百度网盘下载

推荐一款下载下,目前是基于java写的,作者不满java做的图形界面,正在使用go进行重构


Proxyee Down 是一款开源的免费 HTTP 高速下载器，底层使用netty开发，支持自定义 HTTP 请求下载且支持扩展功能，可以通过安装扩展实现特殊的下载需求。

经测试,Oracle官网jdk浏览器正常下载是800k左右,使用proxee down 可以跑满宽带,我家是最高达到10M/S

使用下载器可以达到10M,其他站点同


## 食用方法
### 1.下载别人打包好的exe版

最简单的快捷的方式,下载别人打包的带exe程序的版本,已经内置jre,不依赖用户电脑包含jre

我分享一个之前网上下载的包

解压后双击exe即可

[proxyee down 含jre win版](http://pan.bxmac.com/?/Proxyee%28exe%29.zip)


### 2.上GitHub下载源码自己编译
[Proxyee Down(GitHub)](https://github.com/proxyee-down-org/proxyee-down)

由于基于java编写,所以需要本地环境有jre,或者使用别人打包好的包括jre的包

我这里是下载源码自己编译的

编译成功后会生产一个jar文件

然后执行jar文件,适用于mac,win,linux

执行jar 方式,cd到jar所在路径,在cmd执行命令

```
java -jar proxyee-down-main.jar
```

![0c514b3b5e624b438319fab49ba14e1a.png](https://img.hacpai.com/file/2019/08/0c514b3b5e624b438319fab49ba14e1a-0a39f006.png)

## 食用方法截图

暂无
