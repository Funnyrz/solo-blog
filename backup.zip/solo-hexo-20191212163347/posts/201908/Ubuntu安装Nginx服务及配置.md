title: Ubuntu安装Nginx服务及配置
date: '2019-08-02 15:15:32'
updated: '2019-08-02 15:15:52'
tags: [Linux, Nginx]
permalink: /articles/2019/08/02/1564730132747.html
---
![21d04ae0770e4ea18e8defd7bb874a78.jpg](https://img.hacpai.com/file/2019/08/21d04ae0770e4ea18e8defd7bb874a78-6fae5211.jpg)

网上很多使用源码编译安装,本篇将介绍通过源方式安装

## 1.执行更新操作
```
apt update
```
非root用户下请加上sudo,后面所以命令同,低版本ubuntu使用apt-get替代apt,较新版本可以简写为apt
```
sudo apt update
```

## 2.安装Nginx

```
apt install -y nginx
```

正常情况下都能安装完成
然后查看Nginx状态
```
service nginx status
```

Nginx启动命令
```
service nginx start
```
Nginx停止命令
```
service nginx stop
```
Nginx重启命令
```
service nginx restart
```
注意:nginx默认使用80端口,请确保80端口未被其他程序占用
成功运行的截图
![3d092b3e05b947288cfe25d33a415635.png](https://img.hacpai.com/file/2019/08/3d092b3e05b947288cfe25d33a415635-f78ddf45.png)


## 3.Nginx的一些配置
当nginx安装完成后,在浏览器打开网站首页,80端口服务器就是IP地址,虚拟机就是你的虚拟机IP,会看到如下界面

![9cc1f187c9b840408c05fc9c84f71c77.png](https://img.hacpai.com/file/2019/08/9cc1f187c9b840408c05fc9c84f71c77-60d0ee4b.png)


这个文件地址在:/var/www/html/index.nginx-debian.html

/var/www/html/这个路径就是nginx默认web站点的路径

你可以把自己的程序放在这个目录下就能访问了

### 一些配置

在/etc/nginx路径下可以看到一些nginx相关文件

![f3cbbbb8ca854869a13f0f0a35b14971.png](https://img.hacpai.com/file/2019/08/f3cbbbb8ca854869a13f0f0a35b14971-4e55f89d.png)


然后我们cat nginx.conf

```
cd /etc/nginx
cat nginx.conf
```

看到如下内容

```
user www-data;
worker_processes auto;
pid /run/nginx.pid;

events {
        worker_connections 768;
        # multi_accept on;
}

http {

        ##
        # Basic Settings
        ##

        sendfile on;
        tcp_nopush on;
        tcp_nodelay on;
        keepalive_timeout 65;
        types_hash_max_size 2048;
        # server_tokens off;

        # server_names_hash_bucket_size 64;
        # server_name_in_redirect off;

        include /etc/nginx/mime.types;
        default_type application/octet-stream;

        ##
        # SSL Settings
        ##

        ssl_protocols TLSv1 TLSv1.1 TLSv1.2; # Dropping SSLv3, ref: POODLE
        ssl_prefer_server_ciphers on;

        ##
        # Logging Settings
        ##

        access_log /var/log/nginx/access.log;
        error_log /var/log/nginx/error.log;

        ##
        # Gzip Settings
        ##

        gzip on;
        gzip_disable "msie6";

        # gzip_vary on;
        # gzip_proxied any;
        # gzip_comp_level 6;
        # gzip_buffers 16 8k;
        # gzip_http_version 1.1;
        # gzip_types text/plain text/css application/json application/javascript text/xml application/xml application/xml+rss text/javascript;

        ##
        # Virtual Host Configs
        ##

        include /etc/nginx/conf.d/*.conf;
        include /etc/nginx/sites-enabled/*;
}


#mail {
#       # See sample authentication script at:
#       # http://wiki.nginx.org/ImapAuthenticateWithApachePhpScript
#
#       # auth_http localhost/auth.php;
#       # pop3_capabilities "TOP" "USER";
#       # imap_capabilities "IMAP4rev1" "UIDPLUS";
#
#       server {
#               listen     localhost:110;
#               protocol   pop3;
#               proxy      on;
#       }
#
#       server {
#               listen     localhost:143;
#               protocol   imap;
#               proxy      on;
#       }
#}
```
里面包含了一些配置,但大多数内容被注释了,有2行是在引用其他文件

```
 include /etc/nginx/conf.d/*.conf;
 include /etc/nginx/sites-enabled/*;
```
相当于conf.d和site-enabled目录下所有配置配置都会生效

因为我的程序是java编写的,需要使用tomcat作为容器,但是服务器上又不止放一个站点,使用了不同的端口,所以需要用到nginx做代理分发

我在conf.d目录下新建了一个tomcat.conf文件

```
vim tomcat.conf
```

写入了如下内容

```
server {
         listen       80;
         server_name  bxmac.com www.bxmac.com zxacn.com www.zxacn.com;
         location / {
                  proxy_set_header Host $host;
                  proxy_set_header X-Real-Ip $remote_addr;
                  proxy_set_header X-Forwarded-For $remote_addr;
                  proxy_pass http://localhost:8080;
         }
}
server {
         listen       80;
         server_name  pan.bxmac.com;
         location / {
                  proxy_set_header Host $host;
                  proxy_set_header X-Real-Ip $remote_addr;
                  proxy_set_header X-Forwarded-For $remote_addr;
                  proxy_pass http://localhost:8888;
         }
}
```

上面的配置表示监听80端口,所有通过80端口访问,并且使用的是bxmac.com www.bxmac.com zxacn.com www.zxacn.com,这几个域名的都会跳转到8080这个端口,这个端口是tomcat程序使用的端口

下面的相同,pan.bxmac.com会被代理到8888端口,放到8888端口的程序

以上是nginx的简单应用,菜鸡如我还在进一步了解中