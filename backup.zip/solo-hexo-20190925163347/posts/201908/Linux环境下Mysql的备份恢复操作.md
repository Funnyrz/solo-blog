title: Linux环境下Mysql的备份恢复操作
date: '2019-08-02 15:17:00'
updated: '2019-08-02 15:17:00'
tags: [MySql, Linux]
permalink: /articles/2019/08/02/1564730220016.html
---
本篇记录mysql在不使用图形界面工具情况话,使用命令去做mysql数据的备份恢复

```
mysql -u root -p
```
输入密码,成功则进入mysql的终端命令界面

mysql>

## 查看所有的数据库
```
show databases;
```

以下命令在linux命令下执行
## 备份所有数据库：
```
mysqldump -u root -p --all-database > all.sql
```
## 备份数据库 demo
```
mysqldump -u root -p demo > demo.sql
```
## 备份数据库demo下的test表
```
mysqldump -u root -p demo test > demo_test.sql
```
