title: UnblockNeteaseMusic解锁网易云音乐无版权限制灰色歌单
date: '2019-08-28 12:17:49'
updated: '2019-08-28 13:18:05'
tags: [推荐软件, GitHub, 网易云]
permalink: /articles/2019/08/28/1566965869612.html
---
![](https://img.hacpai.com/bing/20171122.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

## 前言
国内音乐版权之争愈发激烈,用户苦不堪言.网易云音乐作为后起之秀版权方面实现太弱,只能一点一点变灰自己的歌单,但作为一个长期使用网易云的用户,很难放弃转用为其他平台,今天结束一款神器,能够结果网易云音乐灰色歌曲,也就是因为版权导致下架的歌曲.
原理大概就是通过代理网易云请求,检测到因版权下架的音乐使用其他音源作为替代,让用户不用在单独使用其他客户端无感知聆听下架的音乐

## 项目地址

大佬的开源项目,地址托管在github
Github:[https://github.com/nondanee/UnblockNeteaseMusic](https://github.com/nondanee/UnblockNeteaseMusic/)

github上官方给出了安装使用方法,但不够详细,很难成功,我写一篇自己安装搭建的过程

## 安装
使用powerShell或者CMD执行命令,前提是有装Git
```
git clone https://github.com/nondanee/UnblockNeteaseMusic
```
上面命令会下载项目到本地,如果没有装Git,使用浏览器打开项目地址https://github.com/nondanee/UnblockNeteaseMusic 手动下载到本地
![image.png](https://img.hacpai.com/file/2019/08/image-23718b73.png)

![image.png](https://img.hacpai.com/file/2019/08/image-994621d6.png)

下载完成后解压出来


![image.png](https://img.hacpai.com/file/2019/08/image-751d43c3.png)

在文件下按住shift然后右键,可以直接在本文件夹下打开cmd或者powerShell

按住shift再按右键才会出现,或者cmd命令cd到该目录也可以
![image.png](https://img.hacpai.com/file/2019/08/image-618bf8a2.png)


打开了powerShell
![image.png](https://img.hacpai.com/file/2019/08/image-515e4b2f.png)


复制下面命令去执行

```
node app.js -a 127.0.0.1 -p 8090
```
8090端口自己修改,我用的8090这个可以自己修改
![image.png](https://img.hacpai.com/file/2019/08/image-ebd3633c.png)

## 使用

打开网易云配置代理,在设置->工具->代理->自定义代理

![image.png](https://img.hacpai.com/file/2019/08/image-dab4d01a.png)

填写服务器和端口,点击确定会重启,重启后网易云的请求就会到我们刚刚启动的服务
![image.png](https://img.hacpai.com/file/2019/08/image-abf5da14.png)

现在去打开歌单,发现之前灰色的都不在灰色了,比如周杰伦,网易云只有很少杰伦歌曲的版权
![image.png](https://img.hacpai.com/file/2019/08/image-487e3cfa.png)

现在都可以播放了,直接在网易云客户端

如果出现加载失败,需要在启动时加一个参数,指定使用源

```
node app.js -a 127.0.0.1 -p 8090 -o migu
```
使用咪咕音乐作为优先使用源

## docker安装
需要本地有docker环境
```
docker pull nondanee/unblockneteasemusic
```
拉取docker镜像

```
docker run --name unmusic -p 8090:8080 nondanee/unblockneteasemusic -o migu
```
运行镜像

使用方法同上

## 使用方法汇总
官方介绍了三种使用方法,需要去项目看官方文档
### 1.修改host文件
这种方法不配置客户端代理修改host文件即可使用

文件路径:C:\Windows\System32\drivers\etc

![image.png](https://img.hacpai.com/file/2019/08/image-edadb66f.png)

在host新增2行内容
```
<Server IP> music.163.com
<Server IP> interface.music.163.com
```
比如我们本地安装ip地址未127.0.0.1

![image.png](https://img.hacpai.com/file/2019/08/image-ee1c57e3.png)

注意:这种方式启动服务时只能使用80端口且需要增加-f参数,否则会死循环

先使用cmd ping music.163.com拿到ip

![image.png](https://img.hacpai.com/file/2019/08/image-ea99acbf.png)

启动服务命令修改为
```
node app.js -a 127.0.0.1 -p 80 -f 223.252.199.XX -o migu
```
现在打开网易云音乐直接可以播放了
### 2.代理使用
| 平台 |  基础设置 |
| :-- |  :-- |
| Windows |  设置 > 工具 > 自定义代理 (客户端内) |
| UWP |  Windows 设置 > 网络和 Internet > 代理 |
| Linux |  系统设置 > 网络 > 网络代理 |
| macOS |  系统偏好设置 > 网络 > 高级 > 代理 |
| Android |  WLAN > 修改网络 > 高级选项 > 代理 |
| iOS |  无线局域网 > HTTP 代理 > 配置代理 |

Window配置上面已经说过了
### 3. 调用接口
参考官方文档,我没测试过
## 云服务器搭建
使用云服务器搭建有一个好处,不用每次都运行本地的服务器,虽然也可以配置为开机自启,我这里介绍云服务安装,至于做何选择因人而异

首先的有一台云服务器,配置不用多高,带宽大一点比较好

首先在云服务器上安装docker服务,之所以使用docker,因为方便

参考之前写的博文:[Ubuntu14,16,Linux一键安装Docker服务](http://zxacn.com/articles/2019/08/27/1566880504868.html)

然后和之前本地安装相似的操作
```
docker pull nondanee/unblockneteasemusic
```
拉取docker镜像

```
docker run --name unmusic -p 8090:8080 nondanee/unblockneteasemusic -o migu
```
运行镜像
至此一个在线的云服务版本搭建完毕,可以分享给自己的朋友们使用
配置方式如同之前本地一样,把127.0.0.1改为你的服务器IP即可
PS:使用Host方式必须使用80端口
```
docker run --name unmusic -p 80:8080 nondanee/unblockneteasemusic -o migu
```

## 问题汇总
* Q:服务搭建启动完毕,使用时出现加载失败
A:官方说默认使用前四家源,即QQ / 虾米 / 百度 / 酷狗,可能歌曲前四家也无版权
解决办法:在启动时增加参数,优先使用其他源.例如-o
```
docker run --name unmusic -p 8090:8080 nondanee/unblockneteasemusic -o migu
```
优先使用的时咪咕的音源
